package sonert.backend

import io.ktor.application.*
import io.ktor.http.*
import io.ktor.http.cio.websocket.*
import io.ktor.http.content.*
import io.ktor.request.*
import io.ktor.response.*
import io.ktor.routing.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.sessions.*
import io.ktor.util.*
import io.ktor.util.pipeline.*
import io.ktor.websocket.*
import kotlinx.serialization.KSerializer
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.jetbrains.exposed.sql.*
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.transactions.transaction
import sonert.backend.plugins.*
import java.math.BigInteger
import java.util.*
import java.security.KeyPairGenerator
import javax.crypto.Cipher

import java.security.KeyFactory
import java.security.MessageDigest
import java.security.spec.X509EncodedKeySpec

fun PipelineContext<*, ApplicationCall>.getSession(): ResultRow? {
    val session = call.sessions.get<BaseUserSession>() ?: return null

    return transaction {
        Sessions.select { Sessions.sessionId eq session.sessionId }.first()
    }
}

fun md5(input:String): String {
    val md = MessageDigest.getInstance("MD5")
    return BigInteger(1, md.digest(input.toByteArray())).toString(16).padStart(32, '0')
}

fun <T> Decrypt(key: ByteArray, data: ByteArray, serializer: KSerializer<T>): T {
    val crypter = Cipher.getInstance("RSA")
    val keyFactory = KeyFactory.getInstance("RSA")
    val spec = X509EncodedKeySpec(key)

    crypter.init(Cipher.DECRYPT_MODE, keyFactory.generatePrivate(spec))
    return Json.decodeFromString(serializer, crypter.doFinal(data).toString())
}

fun main() {
    Database.connect("jdbc:sqlite:database.db")
    transaction { SchemaUtils.create(Sessions, AuthUsers, Chats, ChatUser, Messages, Vacancy, VacancyChats) }

    val chats = transaction {
        Chats.selectAll().map {
            it[Chats.id].value to Room(
                (ChatUser innerJoin AuthUsers).select { ChatUser.chatId eq it[Chats.id] }
                    .map { User(it[AuthUsers.login], it[AuthUsers.id].value) }.toMutableList(),
                it[Chats.id].value,
                it[Chats.chatName],
                it[Chats.chatDescription],
                    VacancyChats.select {
                        VacancyChats.chatId eq it[Chats.id].value
                    }.map { it[VacancyChats.chatId].value}.toMutableList()
            )
        }.toMap()
    }.toMutableMap()
    if (!chats.containsKey(0)) {
        chats[0] = Room(mutableListOf(), 0, "Global", "", mutableListOf(0))
        transaction {
            Chats.insert {
                it[id] = 0
                it[chatName] = "Global"
                it[chatOwner] = -1
            }
            Vacancy.insert {
                it[id] = 0
                it[vacancyName] = "Default"
            }
            Vacancy.insert {
                it[vacancyName] = "Фронтендер"
            }
            Vacancy.insert {
                it[vacancyName] = "Бэкендер"
            }
            Vacancy.insert {
                it[vacancyName] = "Басист"
            }
            AuthUsers.insert {
                it[login] = "SM"
                it[loginHash] = (md5("SM") + md5("123")).toByteArray()
                it[isChatMaker] = true
            }
            VacancyChats.insert {
                it[vacancyId] = 0
                it[chatId] = 0
            }
        }
    }

    embeddedServer(Netty, port = 3228, host = "0.0.0.0") {
        configureRouting()
        configureSecurity()
        configureSerialization()
        configureSockets()

        routing {
            webSocket("openMessageSocket")
            {

                val session = call.sessions.get<BaseUserSession>()

                if (session == null) {
                    this.close()
                    return@webSocket
                }

                session.user.sockets = this

                chats.forEach{
                    it.value.users.forEach {
                        if (it.id == session.user.id)
                            it.sockets = this
                    }
                }

                //call.sessions.set(session)

                for (frame in incoming) {
                    session.user.sockets = null
                    chats.forEach{
                        it.value.users.forEach {
                            if (it.id == session.user.id)
                                it.sockets = null
                        }
                    }
                    return@webSocket
                }
            }

            static("/") {
                resources()
            }
            route("api") {
                post("start") {
                    val kpg = KeyPairGenerator.getInstance("RSA")
                    kpg.initialize(2048)
                    val keyPair = kpg.genKeyPair()

                    var publicKey = keyPair.public

                    val session = call.sessions.getOrSet {
                        BaseUserSession(
                            UUID.randomUUID().toString(),
                            publicKey.encoded.toString(Charsets.ISO_8859_1),
                            mutableListOf(),
                            User("<blank>")
                        )
                    }

                    val transactionResult = transaction {
                        val localSession = Sessions.select { Sessions.sessionId eq session.sessionId }.firstOrNull()
                        if (localSession != null) {
                            val crypter = Cipher.getInstance("RSA")
                            val keyFactory = KeyFactory.getInstance("RSA")
                            val spec = X509EncodedKeySpec(session.publicKey.toByteArray(Charsets.ISO_8859_1))

                            publicKey = keyFactory.generatePublic(spec)

                            localSession[Sessions.sessionName] != null
                        } else {
                            Sessions.insert {
                                it[sessionId] = session.sessionId
                                it[privateKey] = keyPair.private.encoded
                            }
                            false
                        }
                    }

                    call.respond(StartResponse(transactionResult, publicKey.encoded.toString(Charsets.ISO_8859_1)))
                }

                post("getMyInfo") {
                    val sessionData = getSession()

                    if (sessionData == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    val authId = sessionData[Sessions.authId]

                    if (authId == null) {
                        call.respond(MyInfoResponse(sessionData[Sessions.sessionName] ?: "<blank>", false))
                        return@post
                    }

                    val userData = transaction {
                        AuthUsers.select { AuthUsers.id eq authId }.first()
                    }

                    call.respond(MyInfoResponse(userData[AuthUsers.login], userData[AuthUsers.isChatMaker]))
                }

                post("register") {
                    val sessionData = getSession()

                    if (sessionData == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    //val data = Decrypt(sessionData[Sessions.privateKey], call.receive(), RegisterRequest.serializer())
                    val session = call.sessions.get<BaseUserSession>();
                    val data = call.receive<RegisterRequest>()

                    if (transaction {
                            AuthUsers.select { AuthUsers.login eq data.userLogin }.firstOrNull()
                        } != null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    val authId = transaction {
                        AuthUsers.insertAndGetId {
                            it[login] = data.userLogin
                            it[loginHash] = (md5(data.userLogin) + md5(data.userPassword)).toByteArray()
                            it[isChatMaker] = false
                        }
                    }

                    transaction {
                        Sessions.update({ Sessions.sessionId eq sessionData[Sessions.sessionId] }) {
                            it[sessionId] = sessionData[sessionId]
                            it[privateKey] = sessionData[privateKey]
                            it[sessionName] = data.userLogin
                            it[Sessions.authId] = authId
                        }
                    }

                    session?.user?.userName = data.userLogin
                    session?.user?.authId = authId.value
                    session?.user?.userSettings = 2
                    call.sessions.set(session)

                    call.respond(HttpStatusCode.OK)
                }

                post("login") {
                    val sessionData = getSession()

                    if (sessionData == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    //val data = Decrypt(sessionData[Sessions.privateKey], call.receive(), LoginRequest.serializer())
                    val data = call.receive<LoginRequest>()
                    val session = call.sessions.get<BaseUserSession>();

                    if (data.userPassword != null) {
                        val userData = transaction {
                            AuthUsers.select { AuthUsers.loginHash eq (md5(data.userLogin) + md5(data.userPassword)).toByteArray() }
                                .firstOrNull()
                        }

                        if (userData == null) {
                            call.respond(HttpStatusCode.Unauthorized)
                            return@post
                        }

                        sessionData[Sessions.sessionName] = userData[AuthUsers.login];
                        sessionData[Sessions.authId] = userData[AuthUsers.id];
                        transaction {
                            Sessions.update({ Sessions.sessionId eq sessionData[Sessions.sessionId] }) {
                                it[sessionId] = sessionData[sessionId]
                                it[privateKey] = sessionData[privateKey]
                                it[sessionName] = sessionData[sessionName]
                                it[authId] = sessionData[authId]
                            }
                        }

                        session?.user?.userName = data.userLogin
                        session?.user?.authId = sessionData[Sessions.authId]?.value
                        session?.user?.userSettings = 2
                        call.sessions.set(session)

                        call.respond(HttpStatusCode.OK)
                        return@post
                    }

                    sessionData[Sessions.sessionName] = data.userLogin;
                    transaction {
                        Sessions.update({ Sessions.sessionId eq sessionData[Sessions.sessionId] }) {
                            it[sessionId] = sessionData[sessionId]
                            it[privateKey] = sessionData[privateKey]
                            it[sessionName] = sessionData[sessionName]
                        }
                    }

                    session?.user?.userName = data.userLogin
                    session?.user?.userSettings = 1
                    call.sessions.set(session)
                    call.respond(HttpStatusCode.OK)
                }

                post("getChatHistory") {
                    val sessionData = getSession()

                    if (sessionData == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    val data = call.receive<GetHistoryRequest>()

                    val chatHistory = transaction {
                        Messages.select { Messages.chatId eq data.chatId }.orderBy(Messages.time, SortOrder.DESC)
                            .limit(data.count)
                            .map {
                                Message(
                                    it[Messages.id].value,
                                    it[Messages.userName],
                                    it[Messages.message],
                                    it[Messages.chatId],
                                    it[Messages.time]
                                )
                            }
                    }

                    call.respond(ChatHistoryResponse(chatHistory))
                }

                post("sendMessage") {
                    val sessionData = getSession()

                    if (sessionData == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    val data = call.receive<SendMessageRequest>()

                    transaction {
                        Messages.insert {
                            it[userName] = sessionData[Sessions.sessionName] ?: "<blank>"
                            it[message] = data.message
                            it[chatId] = data.chatId
                            it[time] = data.time
                        }
                    }
                    chats[data.chatId]?.users?.forEach {
                        val result = Json.encodeToString(Message(sessionData[Sessions.sessionName] ?: "<blank>", data.message, data.time, data.chatId))
                        it.sockets?.send(result)

                    }
                    call.respond(HttpStatusCode.OK)
                }

                post("chatConnect") {
                    val sessionData = getSession()

                    val session = call.sessions.get<BaseUserSession>()

                    if (sessionData == null || session == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    val data = call.receive<actionWithChatUser>()

                    if (session.chatsList.find { it == data.chatId } != null) {
                        call.respond(HttpStatusCode.OK)
                        return@post
                    }

                    chats[data.chatId]?.users?.add(session.user)

                    if (sessionData[Sessions.authId] != null) {
                        transaction {
                            ChatUser.insert {
                                it[chatId] = data.chatId
                                it[userId] = sessionData[Sessions.authId]!!.value
                            }
                        }
                    }
                    session.chatsList.add(data.chatId)
                    call.sessions.set(session)
                    call.respond(HttpStatusCode.OK)
                }

                post("disconnectChat")
                {
                    val sessionData = getSession()
                    val session = call.sessions.get<BaseUserSession>()

                    if (sessionData == null || session == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    val data = call.receive<actionWithChatUser>()

                    if (session.chatsList.find { it == data.chatId } == null) {
                        call.respond(HttpStatusCode.OK)
                        return@post
                    }

                    chats[data.chatId]?.users?.remove(session.user)

                    if (sessionData[Sessions.authId] != null) {
                        transaction {
                            ChatUser.deleteWhere {
                                ChatUser.userId.eq(session.user.id) and ChatUser.chatId.eq(data.chatId)
                            }
                        }
                    }
                    session.chatsList.remove(data.chatId)
                    call.sessions.set(session)
                    call.respond(HttpStatusCode.OK)
                }


                post("getChatList")
                {
                    val sessionData = getSession()
                    val session = call.sessions.get<BaseUserSession>()

                    if (sessionData == null || session == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    val data = call.receive<GetChats>()

                    val chatsResponse = ChatListResponse(mutableListOf())

                    chats.forEach {
                        if (transaction {
                                VacancyChats.select {
                                    (VacancyChats.vacancyId inList data.vacancies) and (VacancyChats.chatId eq it.key)
                                }.firstOrNull()
                            } != null)
                        chatsResponse.chat.add(Chat(it.value.roomName, it.value.roomDescription ?: "", it.value.users.find{it.authId == session.user.authId} != null, it.key, transaction {
                            VacancyChats.select {
                                VacancyChats.chatId eq it.key
                            }.map { it[VacancyChats.vacancyId].value}.toMutableList()
                        }))
                    }

                    call.respond(chatsResponse)
                }

                post("logout")
                {
                    val sessionData = getSession()
                    val session = call.sessions.get<BaseUserSession>()

                    if (sessionData == null || session == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    call.sessions.clear<BaseUserSession>()

                    transaction {
                        Sessions.deleteWhere { Sessions.sessionId eq sessionData[Sessions.sessionId] }
                    }

                    call.respondRedirect("http://localhost:3228/index.html")
                }



                post("createChat")
                {
                    val sessionData = getSession()
                    val session = call.sessions.get<BaseUserSession>()

                    if (sessionData == null || session == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    val userData = transaction {
                        AuthUsers.select { AuthUsers.id eq session.user.authId }
                            .firstOrNull()
                    }

                    if (userData == null || !userData[AuthUsers.isChatMaker])
                    {
                        call.respond(HttpStatusCode.Forbidden)
                        return@post
                    }

                    val data = call.receive<createChat>()

                    val newRoomId = transaction {
                        Chats.insertAndGetId {
                            it[chatName] = data.chatName
                            it[chatDescription] = data.chatDescription
                            it[chatOwner] = userData[AuthUsers.id]
                        }
                    }
                    transaction {
                        VacancyChats.insert {
                            it[chatId] = newRoomId
                            it[vacancyId] = 0
                        }
                    }
                    chats[newRoomId.value] = Room(mutableListOf(session.user), newRoomId.value, data.chatName, data.chatDescription, mutableListOf(0))

                    call.respond(newRoomId.value)
                }

                post("setChatVacancy")
                {
                    val sessionData = getSession()
                    val session = call.sessions.get<BaseUserSession>()

                    if (sessionData == null || session == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    val userData = transaction {
                        AuthUsers.select { AuthUsers.id eq session.user.authId }
                            .firstOrNull()
                    }

                    if (userData == null || !userData[AuthUsers.isChatMaker])
                    {
                        call.respond(HttpStatusCode.Forbidden)
                        return@post
                    }

                    val data = call.receive<addChatVacancy>()

                    val chatData = transaction {
                        Chats.select {
                            (Chats.chatOwner eq userData[AuthUsers.id]) and (Chats.id eq data.chatId)
                        }.firstOrNull()
                    }

                    if (chatData == null)
                    {
                        call.respond(HttpStatusCode.Forbidden)
                        return@post
                    }

                    transaction {
                        VacancyChats.deleteWhere {
                            VacancyChats.chatId eq data.chatId
                        }
                    }

                    data.vacList.forEach {
                        val vacId = it
                        transaction {
                            VacancyChats.insert {
                                it[chatId] = data.chatId
                                it[vacancyId] = vacId
                            }
                        }
                    }
                    call.respond(HttpStatusCode.OK)
                }

                post("getVacancyList")
                {
                    val sessionData = getSession()
                    val session = call.sessions.get<BaseUserSession>()

                    if (sessionData == null || session == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    val vacList = transaction {
                        Vacancy.selectAll().toList()
                    }

                    val result = VacanciesResult(mutableListOf())

                    vacList.forEach {
                        if (it[Vacancy.id].value != 0)
                            result.vacancies.add(VacancyResult(it[Vacancy.id].value, it[Vacancy.vacancyName]))
                    }

                    call.respond(result)
                }

                post("getMyChats")
                {
                    val sessionData = getSession()
                    val session = call.sessions.get<BaseUserSession>()

                    if (sessionData == null || session == null) {
                        call.respond(HttpStatusCode.Unauthorized)
                        return@post
                    }

                    val chatList = transaction {
                        Chats.select {
                            Chats.chatOwner eq session.user.authId
                        }.toList()
                    }

                    val result = ChatListResponse(mutableListOf())

                    chatList.forEach {
                        result.chat.add(Chat(it[Chats.chatName], it[Chats.chatDescription] ?: "", false, it[Chats.id].value, transaction {
                            VacancyChats.select {
                                VacancyChats.chatId eq it[Chats.id].value
                            }.map { it[VacancyChats.chatId].value}.toMutableList()
                        }))
                    }

                    call.respond(result)
                }
            }

        }
    }.start(wait = true)
}
