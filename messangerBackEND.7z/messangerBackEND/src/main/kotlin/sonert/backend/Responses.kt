package sonert.backend

import kotlinx.serialization.Serializable
import org.jetbrains.exposed.dao.id.IntIdTable

@Serializable
data class StartResponse(val alreadyLogin: Boolean, val publicKey: String)

@Serializable
data class MyInfoResponse(val userName: String, val rights: Boolean)

@Serializable
data class Message(
    val messageId: Int,
    val userName: String,
    val message: String,
    val chatId: Int,
    val time: Long
)

@Serializable
data class ChatHistoryResponse(val messages: List<Message>)

@Serializable
data class Chat(
    val chatName: String,
    val chatDescription: String,
    val connected: Boolean,
    val chatId: Int,
    val vacancies: MutableList<Int>
)

@Serializable
data class ChatListResponse(val chat: MutableList<Chat>)

@Serializable
data class VacancyResult(
    val id: Int,
    val name: String
)

@Serializable
data class VacanciesResult(
    val vacancies: MutableList<VacancyResult>
)

