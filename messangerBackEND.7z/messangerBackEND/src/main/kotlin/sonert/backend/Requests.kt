package sonert.backend

import kotlinx.serialization.Serializable

@Serializable
data class RegisterRequest(val userLogin: String, val userPassword: String)

@Serializable
    data class LoginRequest(val userLogin: String, val userPassword: String?)

@Serializable
data class SendMessageRequest(val chatId: Int, val message: String, val time: Long)

@Serializable
data class GetHistoryRequest(val chatId: Int, val count: Int)

@Serializable
data class actionWithChatUser(val chatId: Int, val chatKey: String?)

@Serializable
data class createChat(val chatName: String, val chatDescription: String)

@Serializable
data class addChatVacancy(val chatId: Int, val vacList: List<Int>)

@Serializable
data class GetChats(val vacancies: List<Int>)