package sonert.backend

import org.jetbrains.exposed.dao.id.IntIdTable
import org.jetbrains.exposed.sql.Table
import sonert.backend.Sessions.nullable

const val maxStringLength = 36

object Sessions : Table() {
    val sessionId = varchar("sessionUUID", maxStringLength).index()
    val privateKey = binary("pKey", 2048)
    val sessionName = varchar("sessionName", maxStringLength).nullable()
    val authId = reference("authId", AuthUsers.id).nullable()

    override val primaryKey = PrimaryKey(sessionId)
}

object AuthUsers : IntIdTable(columnName = "authId") {
    val login = varchar("login", maxStringLength).uniqueIndex()
    val loginHash = binary("loginHash", 1024)
    val isChatMaker = bool("isChatMaker")
}

object Chats : IntIdTable(columnName = "chatId") {
    val chatOwner = reference("authId", AuthUsers.id)
    val chatName = varchar("chatName", maxStringLength)
    val chatDescription = text("chatDescription").nullable()
}

object Vacancy : IntIdTable(columnName = "vacancyId") {
    val vacancyName = varchar("vacancyName", maxStringLength)
}

object VacancyChats : Table() {
    val chatId = reference("chatId", Chats.id)
    val vacancyId = reference("vacancyId", Vacancy.id)

    override val primaryKey = PrimaryKey(chatId, vacancyId)
}

object ChatUser : Table() {
    val chatId = reference("chatId", Chats.id)
    val userId = reference("userId", AuthUsers.id)

    override val primaryKey = PrimaryKey(chatId, userId)
}

object Messages : IntIdTable(columnName = "messageId") {
    val userName = varchar("userName", maxStringLength)
    val message = varchar("message", 1024)
    val chatId = integer("chatId")
    val time = long("time")
}

