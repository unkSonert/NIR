package sonert.backend.plugins

import io.ktor.http.cio.websocket.*
import kotlinx.serialization.Serializable

class User (var userName: String, var authId: Int? = null, val id: Int = nextId++, var userSettings: Int = 0) {
    companion object {
        private var nextId: Int = 1
    }

    var sockets: DefaultWebSocketSession? = null
}

class Room (val users: MutableList<User> = mutableListOf(), val roomId: Int, val roomName: String, val roomDescription: String?, val vacancies: MutableList<Int>, val roomSettings: Int = 0) {

}

@Serializable
data class Message(val userName: String, val message: String, val time: Long, val chatId: Int)