package sonert.backend.plugins

import io.ktor.sessions.*
import io.ktor.application.*
import io.ktor.response.*
import io.ktor.request.*
import io.ktor.routing.*
import java.io.File
import java.security.PublicKey

fun Application.configureSecurity() {
    install(Sessions) {
        cookie<BaseUserSession>("BASE_SESSION", storage = directorySessionStorage(File("sessions.sessions")))
    }
}

data class BaseUserSession(val sessionId: String, val publicKey: String, val chatsList: MutableList<Int>, val user: User)

