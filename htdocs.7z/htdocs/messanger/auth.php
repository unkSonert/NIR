<form action="../index.php?link=auth" method="post">
    <h5>Авторизация</h5>
    <div class="mb-3">
        <label for="user-name" class="form-label">Логин</label>
        <input type="text" class="form-control" id="user-name" name="login">
    </div>
    <div class="mb-3">
        <label for="user-password" class="form-label">Пароль</label>
        <input type="password" class="form-control" id="user-password" name="password">
    </div>
    <input name="do-auth" hidden>
    <button type="submit" class="btn btn-primary">Отправить</button>
    <a href="../index.php?link=registr">Зарегистрироваться</a>
</form>