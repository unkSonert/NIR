<?php
session_start();

if(empty($_SESSION['user']))
    header("location: ../../");

if (!empty($_GET['link'])) {
    if ($_GET['link'] === 'logout') {
        unset($_SESSION['user']);
        session_destroy();
        header("location: ../../");
    }
}

?>
<!doctype html>
<html>
<head>
    <script>
        function sendMessage (event) {
            event.preventDefault();
            const messageForm = document.querySelector("#message_form");
            const data = {
                action: "send",
                message: messageForm.message_input.value,
                user_name: "<?php echo $_SESSION['user'][1];?>"
            }
            fetch("/messanger/chat/messageResolver.php", {
                method: "post",
                headers: {
                    "Content-type": "application/json"
                },
                body: JSON.stringify(data)
            })
            document.querySelector("textarea").value = "";
        }

        function getMessages () {
            fetch("/messanger/chat/messageResolver.php", {
                method: "post",
                headers: {
                    "Content-type": "application/json"
                },
                body: JSON.stringify({action: "history"})
            }).then(response => response.json()).then(data => {
                const messageStore = document.querySelector("#message_store");
                messageStore.innerHTML = "";
                data.reverse().forEach(message => {
                    messageStore.innerHTML +=
                        `<div class="card" style="margin-bottom: 5px;">
                        <div class="card-body">
                            <h5 class="card-title">${message.user_name}</h5>
                            <p class="card-text">${message.message}</p>
                        </div>
                    </div>`

                });
            })
        }
    </script>
    <meta charset="utf-8">
    <title>Чат</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
</head>
<body>

<div class="container">
    <?php echo "Привет, ".$_SESSION['user'][1]; ?> | <a href="index.php?link=logout">Выйти</a>
    <div class="row m-2">
        <div class="col-3"></div>
        <div class="col-6">
            <form id="message_form" style="display: flex; flex-direction: column; align-items: center; width: 100%;">
                <div class="mb-3">
                    <textarea name="message_input" style="resize: none; width: 100%; height: 64px; position: relative;" cols="128"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Отправить</button>
            </form>
        </div>
        <div class="col-3"></div>
    </div>
    <div class="row">
        <div id="message_store" class="col">
        </div>
    </div>
</div>

<script>
    document.querySelector("#message_form").addEventListener("submit", sendMessage);
    setInterval(getMessages, 1000);
</script>
</body>
</html>