<?php

namespace App;


abstract class Component {
    abstract public function __construct(array $params);

    abstract public function Render(): void;

    protected array $params;
}
