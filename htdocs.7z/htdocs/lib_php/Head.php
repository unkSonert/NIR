<?php

namespace App;


require_once 'Part.php';


class Head extends Part {
    public function __construct(array $params) {
        $this->params['title'] = $params['title'];
        $this->params['cssRef'] = $params['cssRef'];
    }

    public function Render(): void {
        echo <<<HEAD_PART
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <link rel="stylesheet" href="{$this->params['cssRef']}">
                <title>{$this->params['title']}</title>
            </head>
            <body>
        HEAD_PART;
    }
}
