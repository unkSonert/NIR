<?php

namespace App;


require_once 'Part.php';


class Footer extends Part {
    public function __construct(array $params) {
    }

    public function Render(): void {
        echo <<<FOOTER_PART
                <footer>
                </footer>
            </body>
            </html>
        FOOTER_PART;
    }
}
