<?php

namespace App;


require_once 'Head.php';
require_once 'Body.php';
require_once 'Footer.php';


class Page {
    public function __construct(Head $head, Body $body, Footer $footer) {
        $this->_head = $head;
        $this->_body = $body;
        $this->_footer = $footer;
    }

    public function Render(): void {
        @$this->_head->Render();
        @$this->_body->Render();
        @$this->_footer->Render();
    }

    private Head $_head;
    private Body $_body;
    private Footer $_footer;
}
