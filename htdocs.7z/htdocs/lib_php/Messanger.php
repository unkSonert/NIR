<?php


namespace App;
require_once "./lib_php/Component.php";

class Messanger extends Component
{
    public function __construct(array $params)
    {
        $this->params['username'] = $params['username'];
    }

    public function Render(): void
    {
        echo <<< MESSANGER_COMPONENT
        <div class="container">
            <p>Привет, <strong id="username">{$this->params['username']}</strong></p> <a href="index.php?link=logout">Выйти</a>
            <form id="message_form" class="form margin-bottom" style="display: flex; flex-direction: column; align-items: center; width: 100%;">
                <div class="mb-3">
                    <textarea class="form-control" name="message_input" style="resize: none; width: 100%; height: 64px; position: relative;" cols="128"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Отправить</button>
            </form>
            <div id="message_store" class="col"></div>
        </div>
        <script src="main.js"></script>
        MESSANGER_COMPONENT;

    }
}