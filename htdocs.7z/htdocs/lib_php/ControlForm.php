<?php

namespace App;
require_once "./lib_php/Component.php";

class ControlForm extends Component
{

    public function __construct(array $params)
    {
        $this->params['form_type'] = $params['form_type'];
    }

    public function Render(): void
    {
        if ($this->params['form_type'] == "registr")
        {
            echo <<<USER_DATA_FORM_COMPONENT
            <div class="modal">
                <form action="authResolver.php" method="post" class="form">
                    <h5 class="form-header">Регистрация</h5>
                    <div class="mb-3">
                        <label for="user-name" class="form-label">Логин</label>
                        <br>
                        <input type="text" class="form-control" id="user-name" name="login">
                    </div>
                    <div class="mb-3">
                        <label for="user-password" class="form-label">Пароль</label>
                        <br>
                        <input type="password" class="form-control" id="user-password" name="password">
                    </div>
                    <input name="reg" hidden>
                    <button type="submit" class="btn btn-primary">Отправить</button>
                    <a href="index.php?link=auth">Авторизация</a>
                </form>
            </div>
            USER_DATA_FORM_COMPONENT;
        }
        else
        {
            echo <<<USER_DATA_FORM_COMPONENT
            <div class="modal">
                <form action="authResolver.php" method="post" class="form">
                    <h5 class="form-header">Авторизация</h5>
                    <div class="mb-3">
                        <label for="user-name" class="form-label">Логин</label>
                        <br>
                        <input type="text" class="form-control" id="user-name" name="login">
                    </div>
                    <div class="mb-3">
                        <label for="user-password" class="form-label">Пароль</label>
                        <br>
                        <input type="password" class="form-control" id="user-password" name="password">
                    </div>
                    <input name="auth" hidden>
                    <button type="submit" class="btn btn-primary">Отправить</button>
                    <a href="index.php?link=registr">Зарегистрироваться</a>
                </form>
            </div>
            USER_DATA_FORM_COMPONENT;
        }
    }
}