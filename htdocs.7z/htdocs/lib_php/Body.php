<?php

namespace App;


require_once 'Part.php';


class Body extends Part {
    public function __construct(array $params) {
        $this->params['components'] = $params['components'];
    }

    public function Render(): void {
        foreach ($this->params['components'] as $component) {
            $component->Render();
        }
    }
}
