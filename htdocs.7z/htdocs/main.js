function sendMessage (event) {
    event.preventDefault();
    const messageForm = document.querySelector("#message_form");
    const data = {
        action: "send",
        message: messageForm.message_input.value,
        user_name: document.querySelector("#username").innerHTML
    }
    fetch("/messageResolver.php", {
        method: "post",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(data)
    })
    document.querySelector("textarea").value = "";
}

function getMessages () {
    fetch("/messageResolver.php", {
        method: "post",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify({action: "history"})
    }).then(response => response.json()).then(data => {
        const messageStore = document.querySelector("#message_store");
        messageStore.innerHTML = "";
        data.reverse().forEach(message => {
            messageStore.innerHTML +=
                `<div class="card" style="margin-bottom: 5px;">
                        <div class="card-body">
                            <h5 class="card-title">${message.user_name}</h5>
                            <p class="card-text">${message.message}</p>
                        </div>
                    </div>`

        });
    })
}

document.querySelector("#message_form").addEventListener("submit", sendMessage);
setInterval(getMessages, 1000);