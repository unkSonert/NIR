<?php
session_start();

$connection = mysqli_connect("localhost", "root", "", "messanger") or die("Error!!!");
if(mysqli_connect_errno()) echo mysqli_connect_error();


if(isset($_POST['reg'])){
    $login = htmlspecialchars(trim($_POST['login']));
    $password = md5(htmlspecialchars(trim($_POST['password'])));
    $query_auth = mysqli_query($connection, "SELECT * FROM users WHERE login = '$login'");
    if(mysqli_num_rows($query_auth) == 1){
        header("location: index.php?link=auth");
    }
    if(!empty($login) and !empty($password)){
        mysqli_query($connection, "INSERT INTO users (login, password) VALUES ('$login', '$password') ");
        header("location: index.php");
    }
}

if(isset($_POST['auth'])){
    $login = htmlspecialchars(trim($_POST['login']));
    $password = md5(htmlspecialchars(trim($_POST['password'])));
    $query_auth = mysqli_query($connection, "SELECT * FROM users WHERE login = '$login' AND password = '$password' ");
    if(mysqli_num_rows($query_auth) == 1){
        $row_auth = mysqli_fetch_assoc($query_auth);
        $_SESSION['user'] = array($row_auth['id'], $row_auth['login'], $row_auth['password']);
        header("location: index.php");
    }
}

