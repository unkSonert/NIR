<?php
session_start();
require_once "./lib_php/Page.php";
require_once "./lib_php/Head.php";
require_once "./lib_php/Body.php";
require_once "./lib_php/Footer.php";

require_once "./lib_php/ControlForm.php";
require_once "./lib_php/Messanger.php";

if (!empty($_GET['link'])) {
    if ($_GET['link'] === 'logout') {
        unset($_SESSION['user']);
        session_destroy();
        header("index.php");
    }
}

$ftype = $_GET['link'] ?? "";
$page = new App\Page(
        new App\Head([
                "title" => "NIR",
                "cssRef" => "main.css"
        ]),
        new App\Body([
                "components" => [
                    empty($_SESSION['user']) ? new \App\ControlForm(["form_type" => $ftype]) : new \App\Messanger(["username" => $_SESSION['user'][1]])
                ]
        ]),
        new App\Footer([])
);
$page->Render();