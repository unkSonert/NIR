<?php
$_SERVER["CONTENT_TYPE"] = 'application/json';
$connection = mysqli_connect("localhost", "root", "", "messanger") or die("Error!!!");

if (mysqli_connect_errno()) echo mysqli_connect_error();
$postData = file_get_contents('php://input');
$data = json_decode($postData, true);

	if (isset($data['action']) && $data['action'] === "send"){

        $userName = htmlspecialchars(trim($data['user_name']));
        $message = htmlspecialchars(trim($data['message']));
        if(!empty($message)){
            mysqli_query($connection, "INSERT INTO message (user_name, message) VALUES ('$userName', '$message') ");
        }
    }

	if(isset($data['action']) && $data['action'] === "history") {
        $messages = [];
        $result = mysqli_query($connection, "SELECT user_name, message FROM message");
            while ($row = $result->fetch_assoc()) {
                $messages[] = ($row);
            }
        echo json_encode($messages);
    }

?>